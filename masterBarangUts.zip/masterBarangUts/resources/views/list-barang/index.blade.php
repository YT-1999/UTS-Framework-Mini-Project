@extends('layouts.app')

@section('content')
    <div class="container">
        <h2 class="pb-4">List Barang</h2>
        <a class="btn btn-success px-4" href="{{ route('barangs.create') }}">Tambah</a>
        <table class="table table-striped mt-4">
            <thead>
                <tr>
                    <th scope="col">Kode Barang</th>
                    <th scope="col">Nama Barang</th>
                    <th scope="col">Harga Barang</th>
                    <th scope="col">Satuan Barang</th>
                    <th scope="col">Deskripsi Barang</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                @foreach ($data_barang as $d)
                <tr>
                    <td>{{ $d->kode_barang}}</td>
                    <td>{{ $d->nama_barang}}</td>
                    <td>{{ number_format($d->harga_barang, 0, ',', '.')}}</td>
                    <td>{{ $d->satuan->kode_satuan}}</td>
                    <td>{{ $d->deskripsi_barang}}</td>

                    <td>
                        <a class="btn btn-sm btn-outline-info" href="{{ route('barangs.show', $d->id)}}">Detail</a>
                        <a class="btn btn-sm btn-outline-warning" href="{{ route('barangs.edit', $d->id)}}">Edit</a>
                        <form action="{{ route('barangs.destroy', $d->id )}}" method="POST" type="button" class="btn btn-outline-danger p-0" onsubmit="return confirm('Kamu Yakin Mau Hapus Data ?')" >
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-sm btn-outline-danger m-0 border-0">Hapus</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
