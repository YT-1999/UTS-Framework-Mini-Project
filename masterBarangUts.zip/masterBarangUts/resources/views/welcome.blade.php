@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="home container-xxl">
            <h2 class="pb-3 text-center">Biodata Diri</h2>
            <div class="row justify-content-center py-5 rounded-4">
                <div class="col-4 align-self-center">
                    <div class="mb-4">
                        <label class="pb-1">Nama Lengkap</label>
                        <h5>Yasmien Tamalin</h5>
                    </div>

                    <div class="mb-4">
                        <label class="pb-1">Tempat, tanggal lahir</label>
                        <h5>Jakarta 05-Mei-1999</h5>
                    </div>

                    <div class="mb-4">
                        <label class="pb-1">Jenis kelamin</label>
                        <h5>Perempuan</h5>
                    </div>

                    <div class="mb-4">
                        <label class="pb-1">Golongan Darah</label>
                        <h5>O</h5>
                    </div>
                </div>

                <div class="col-5 align-self-center">
                    <div class="mb-4">
                        <label class="pb-1">Email</label>
                        <h5>yasmientamalin218@student.ittelkom-sby.ac.id</h5>
                    </div>

                    <div class="mb-4">
                        <label class="pb-1">Nomor Telepon</label>
                        <h5>0877867720021</h5>
                    </div>

                    <div class="mb-4">
                        <label class="pb-1">Alamat</label>
                        <h5>Komplek Pembangunan Perumahan (PP) Blok D.3 RT/RW 003/004 Mekarsari, Cimanggis, Depok</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
