<!-- Sidebar -->
<div class="sidebar container-fluid">
    <div class="sidebar-design">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link px-3" href="{{ route('Home')}}">
                    <i class="fas fa-home"></i>
                    <span>Home</span>
                </a>
            </li>
            <li class="nav-item pt-3">
                <a class="nav-link px-3" href="{{ route('barangs.index')}}">
                    <i class="fas fa-user"></i>
                    <span>List Barang</span>
                </a>
            </li>
        </ul>
    </div>
</div>
